# Play_school_Management
play school site with Admission form using html, php,mysql
